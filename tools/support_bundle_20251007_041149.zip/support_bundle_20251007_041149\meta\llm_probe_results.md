# LLM Probe Results

Generated: 2025-10-03T20:49:28.379692+00:00

| Model | JSON Strict | Short Prompt | Long Prompt |
| --- | --- | --- | --- |
| gemma3:4b | ✅ | 0.45s, len=3, ok, ✅ | 18.99s, len=975, ok, ⚠️ |
| llama3.1:8b | ❌ | n/a, len=0, empty, ✅, errors | n/a, len=0, empty, ✅, errors |
| qwen2.5:7b | ❌ | n/a, len=0, empty, ✅, errors | n/a, len=0, empty, ✅, errors |

Notes: latency is in seconds, length counts raw characters, and non-ASCII detection is heuristic.